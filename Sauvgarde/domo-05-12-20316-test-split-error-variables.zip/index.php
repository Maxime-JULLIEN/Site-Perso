<?php
	include $_SERVER['DOCUMENT_ROOT']."/bbd_connect.php" ;
global $devices;
 global $categories;
$devices = $bdd->query('SELECT * FROM devices');
$categories = $bdd->query('SELECT * FROM categories');
	include $_SERVER['DOCUMENT_ROOT'].'/ressources/structure/head/head.php';
	include $_SERVER['DOCUMENT_ROOT'].'/ressources/structure/entete/entete.php';
	include $_SERVER['DOCUMENT_ROOT'].'/ressources/structure/menu/menu.php';
	/* include("/content/index.php"); */
?>
<!--
<div id="container"></div>
<script>
$("#container").load("/content/index.php");
</script> -->
	
