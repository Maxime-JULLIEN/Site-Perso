<!doctype html>
<html lang="fr">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
	<meta name="mobile-web-app-capable" content="yes">
	<title>Titre de la page</title>
	<link rel="icon" type="image/png" href="/ressources/img/favicon.png" />
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<link rel="stylesheet" href="https://code.getmdl.io/1.2.1/material.indigo-pink.min.css">
	<script defer src="https://code.getmdl.io/1.2.1/material.min.js"></script>
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
	<link rel="stylesheet" href="/ressources/css/style.css">
	<script src="/ressources/js/script.js"></script>
</head>

	<body>
		<div class="mdl-layout mdl-js-layout mdl-layout--fixed-drawer mdl-layout--fixed-header">
			<header class="mdl-layout__header mdl-layout__header--waterfall">
				<div class="mdl-layout__header-row"> <span class="mdl-layout-title">Home</span>
					<div class="mdl-layout-spacer"></div>
					<div class="mdl-textfield mdl-js-textfield mdl-textfield--expandable
                  mdl-textfield--floating-label mdl-textfield--align-right">
						<label class="mdl-button mdl-js-button mdl-button--icon" for="fixed-header-drawer-exp"> <i class="material-icons">search</i> </label>
						<div class="mdl-textfield__expandable-holder">
							<input class="mdl-textfield__input" type="text" name="sample" id="fixed-header-drawer-exp"> </div>
					</div>
				</div>
			</header>
			<div class="mdl-layout__drawer"> <span class="mdl-layout-title">My Home</span>
				<nav class="mdl-navigation"> <a class="mdl-navigation__link" href="">Général</a> <a class="mdl-navigation__link" href="">Favoris</a> <a class="mdl-navigation__link" href="">Link</a> <a class="mdl-navigation__link" href="">Link</a> </nav>
			</div>
			<main class="mdl-layout__content mdl-color--grey-100">
				<div class="page-content mdl-grid demo-content">
					
					<div class="mdl-card mdl-color--white mdl-shadow--2dp mdl-cell mdl-cell--4-col disabled">
						<?php 	$ID = "1"; include('bbd_connect.php'); ?>
						<div class="mdl-card-picture mdl-card--expand"></div>
						<div class="mdl-card__supporting-text">Consommation actuelle : 42W</div>
						<div class="mdl-card__actions mdl-card--border">
							<label class="mdl-switch mdl-js-switch mdl-js-ripple-effect" for="switch-1"> <span class="mdl-switch__label mdl-card__title-text">Multiprise</span>
								<input type="checkbox" id="switch-1" class="mdl-switch__input" onchange="object(this,'<?php echo $IP ?>'); myFunction2('<?php echo $ID; ?>'); " <?php echo $ButtonState; ?>> </label>
						</div>
					</div>
					
					
					<div class="mdl-card mdl-color--white mdl-shadow--2dp mdl-cell mdl-cell--4-col">
					<?php 	$ID = "2"; include('bbd_connect.php'); ?>
						<div class="mdl-card-picture2 mdl-card--expand"></div>
						<div class="mdl-card__supporting-text">Consommation actuelle : 42W</div>
						<div class="mdl-card__actions mdl-card--border">
							<label class="mdl-switch mdl-js-switch mdl-js-ripple-effect" for="switch-2"> <span class="mdl-switch__label mdl-card__title-text">Multiprise</span>
								<input type="checkbox" id="switch-2" class="mdl-switch__input" onchange="object(this,'<?php echo $IP; ?>'); myFunction2('<?php echo $ID; ?>'); " <?php echo $ButtonState; ?> disabled> </label>
						</div>
					</div>
					
					</div>
			</main>
		</div>
	</body>

</html>