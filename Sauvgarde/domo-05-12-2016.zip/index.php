<?php
	include("ressources/structure/head/head.php");
	include("bbd_connect.php");
$devices = $bdd->query('SELECT * FROM devices');
$categories = $bdd->query('SELECT * FROM categories');
	include("ressources/structure/entete/entete.php");
	?>
	<style>
		.bottom {
			position: absolute;
			bottom: 0;
			margin-bottom: 20px;
		}

		.bottom-right {
		position: fixed;
    display: block;
    right: 0;
    bottom: 0;
padding-bottom: 23px;
			padding-right: 23px;
    z-index: 900;
		}
		
		.center {
			display: flex;
			justify-content: center;
		}
	</style>
	<div class="mdl-layout__drawer"> <span class="mdl-layout-title">Catégories</span>
		<div class="tr1">
			<nav class="mdl-navigation">
				<?php
								while ($donnees = $categories->fetch())
									{
										$Name = $donnees['Name'];
										$Link = $donnees['Link'];
										echo '<a class="mdl-navigation__link" href="'.$Link.'">'.$Name.'</a> ';
									}
							$categories->closeCursor();
								?>
					<!--	<a class="mdl-navigation__link bottom-button" href="">Test bouton</a> --></nav>
			<div class="center">
				<input type="button" value="Récupérer les données" onclick="getDOMImplementation('test.php', getData);" />
				<div class="bottom">
					<button class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent">Ajouter une catégorie</button>
				</div>
			</div>
		</div>
	</div>
	<main class="mdl-layout__content mdl-color--grey-100">
		<div class="page-content mdl-grid demo-content">
			<?php
					
while ($donnees = $devices->fetch())
{
	$ID = $donnees['ID'];
	$State = $donnees['State'];
	$IP = $donnees['IP'];
	$Link = $donnees['Link'];
	$ON = $donnees['ON'];
	$OFF = $donnees['OFF'];
	$name = $donnees['Name'];
	$img_link = $donnees['img_link'];
	$conso = $donnees['conso'];
	$Connected = $donnees['Connected'];
	if($Connected == "0"){$Connected="disabled";} else{$Connected="";};
	if($State == "1"){$ButtonState="checked";} else{$ButtonState="";};
	echo '
	<style>
	.mdl-card-picture'.$ID.' {
	 background:url(\'/'.$img_link .'\') center center #324a5e;
	    background-size: cover;
}
</style>';
	echo '<div class="mdl-card mdl-color--white mdl-shadow--2dp mdl-cell mdl-cell--4-col '.$Connected.' " >
						<div class="mdl-card-picture'.$ID.' mdl-card--expand"></div>
						<div class="mdl-card__supporting-text">Consommation actuelle : '   .$conso.    ' W</div>
						<div class="mdl-card__actions mdl-card--border">
							<label class="mdl-switch mdl-js-switch mdl-js-ripple-effect" for="switch'.$ID.'"> <span class="mdl-switch__label mdl-card__title-text">'.$name.'</span>
								<input type="checkbox" id="switch'.$ID.'" class="mdl-switch__input" onchange="object(this, \''   .$IP.    '\', \''   .$Link.    '\', \''   .$ON.    '\',\''   .$OFF.    '\'); myFunction2(' .$ID. '); " '.$ButtonState.'> </label>
						</div>
					</div> ';
};

$devices->closeCursor();
			
			?>
		</div>
		<div class="bottom-right">
			<button class="mdl-button mdl-js-button mdl-button--fab mdl-button--colored"> <i class="material-icons">add</i> </button>
		</div>
	</main>
	</div>
	</body>

	</html>