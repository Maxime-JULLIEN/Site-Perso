<?php 	include("ressources/structure/head/head.php"); ?>
<div id="container"></div>
<script>
$("#container").load("index.php");
</script>